from pathlib import Path
import subprocess,json,time
from itertools import chain
h=Path.cwd()
bin=h/'_build/native/release/build/cmd/mooneventeval/mooneventeval.exe'
f=h/'edge.json'; maxb=8388608
def check(label,s,code,ev,offset=None):
    f.write_bytes(s)
    st=time.monotonic()
    p=subprocess.run([bin,'evaluate',f,'--format','json'],capture_output=True,timeout=15)
    e=json.loads(p.stdout)['error']
    assert (p.returncode,p.stderr,e['code'])==(ev,b'',code),(label,p,e)
    if offset is not None:
        assert e['message'].endswith(f'offset {offset} (zero-based)')
    print(f'{label} {len(s)} bytes {p.returncode}/{code} {time.monotonic()-st:.3f}s')
keys=b','.join((f'"{k:x}":0'.encode() for k in range(420000)))
wide=b'{'+keys+b', "0":1}'
check('wide420000',wide+b' '*(maxb-len(wide)),'DUPLICATE_KEY',2,wide.rindex(b'"0"'))
large=(b'{' + b'"' +b'x'*4194291+b'":0,'+b'"'+b'x'*4194291+b'":1}')
check('long',large+b' '*(maxb-len(large)),'DUPLICATE_KEY',2,large.index(b',"')+1)
check('byte-limit',large+b' '*(maxb+1-len(large)),'RESOURCE_LIMIT',3)
check('depth16',b'['*15+b'{"":0,"":0}'+b']'*15,'DUPLICATE_KEY',2,21)
check('depth17',b'{"":1,"":'+b'['*16+b'0'+b']'*16+b'}','RESOURCE_LIMIT',3)
check('syntax-later',b'{"":1,"":3} '+b'garbage','INVALID_JSON',2)
check('surrogate-later',b'{"":1,"":3,"later":"\\ud800"}','INVALID_JSON',2)
check('utf8-later',b'{"":1,"":3}'+bytes([255]),'INVALID_UTF8',2)
