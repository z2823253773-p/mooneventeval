from pathlib import Path
import json, random, subprocess, re, collections
r=random.Random(836223)
here=Path(__file__).resolve().parent
suffix='_build/native/release/build/cmd/mooneventeval/mooneventeval.exe'
p=here/'adversarial.json'
counts=collections.Counter()
keys=['', '"', '\\', '/', '\x00', 'a\x1b\x7f\u202e', 'e\u0301', 'é', '😀', '\ufeff', '\r\n', '🔑'*64, '🍄'*65, 'α\\":{},[]']
class Obj(list): pass
def gen(n):
    t=r.randrange(5 if n else 2)
    if t==0: return r.choice(keys)
    if t==1: return r.choice([None, True, 0, False, -0.5])
    if t==2: return [gen(n-1) for _ in range(r.randrange(5))]
    return Obj((r.choice(keys),gen(n-1)) for _ in range(r.randrange(5)))
def run(b):
    q=subprocess.run([b, 'evaluate',p,'--format','json'],capture_output=True,timeout=12)
    return (q.returncode,q.stdout,q.stderr)
for i in range(500):
    doc=gen(4)
    ws=lambda:r.choice(['',' ', '\r\n', '\t',' \n\t\r'])
    chunks=[]; position=0; hit=None
    def emit(s):
        global position
        chunks.append(s); position+=len(s.encode('utf-16-le'))//2
    def render(x):
        global hit
        if isinstance(x,Obj):
            emit('{'+ws()); seen=set()
            for j,(k,v) in enumerate(x):
                if j: emit(','+ws())
                if k in seen and hit is None: hit=(k,position)
                seen.add(k)
                emit(json.dumps(k,ensure_ascii=r.choice([True,False])).replace('/',r.choice(['/','\\/'])))
                emit(ws()+':'+ws()); render(v); emit(ws())
            emit('}')
        elif isinstance(x,list):
            emit('['+ws())
            for j,v in enumerate(x):
                if j: emit(','+ws())
                render(v); emit(ws())
            emit(']')
        else: emit(json.dumps(x,ensure_ascii=r.choice([True,False])))
    emit(ws()); render(doc); emit(ws())
    p.write_bytes((b'\xef\xbb\xbf' if i%2 else b'')+''.join(chunks).encode())
    actual=run(here/suffix)
    if hit is None:
        assert actual==run(here/'base'/suffix),(i,doc,actual)
        counts['unique-byte-identical-to-base']+=1
    else:
        k,offset=hit
        err=json.loads(actual[1])['error']
        assert (actual[0],actual[2],err['code'],err['path'])==(2,b'','DUPLICATE_KEY','$'),(i,actual)
        assert err['kind']=='input',(i,err)
        m=re.fullmatch(r'Duplicate JSON object key (.*) at UTF-16 offset ([0-9]+) \(zero-based\)',err['message'])
        assert m and json.loads(m[1])==k[:64]+('...' if len(k)>64 else '') and int(m[2])==offset,(i,hit,err)
        for c in m[1]:
            assert ord(c)>31 and ord(c) not in (127,0x202e,0xfeff)
        counts['duplicate-first-key-offset-preview']+=1
print(dict(counts))
