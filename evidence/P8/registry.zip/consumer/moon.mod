name = "example/eventeval_registry_acceptance"
version = "0.0.0"
preferred_target = "native"

import {
  "z2823253773-p/mooneventeval@0.1.0",
}
