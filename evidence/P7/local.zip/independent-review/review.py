from pathlib import Path
import subprocess as sp, json, random, hashlib, time, zipfile
from decimal import Decimal
root=Path.cwd()
rel=Path('_build/native/release/build/cmd/mooneventeval/mooneventeval.exe')
exe=root/'unpack'/rel
base=root/'base'/rel
header=b'filename\tonset\toffset\tevent_label\n'
ref=root/'ref'; pred=root/'pred'; task=root/'task'
def run(exe,*args):
    p=sp.run([exe,*args],capture_output=True,timeout=8)
    return p.returncode,p.stdout,p.stderr
def check(refb,predb,exp=None,code=2):
    ref.write_bytes(refb);pred.write_bytes(predb)
    status,o,e=run(exe,'import-tsv',ref,'--prediction',pred)
    assert e==b'' and o.endswith(b'\n') and o.count(b'\n')==1
    d=json.loads(o)
    if exp:
        assert status==code and list(d)==['schema_version','status','error'] and d['status']=='failed' and all(d['error'][k]==v for k,v in exp.items()), (d,exp)
    else:
        assert status==0,d
        assert d['config']=={'collar_s':'0.2','offset_ratio':'0.5'}
        task.write_bytes(o)
    return d
# Deterministic randomized Unicode/escaping, row mapping and union oracle
rnd=random.Random(719)
names=['轨','a " ', 'a\\b','\x00','🌒','\ue000']
labels=[' 类"','\x00','🌿','\ufeff','k',"e\u0301",'é']
for iteration in range(40):
    inputs=[]; groups={}; labs=set()
    for side in ['reference','prediction']:
        ending=rnd.choice(['\r\n','\n'])
        lines=[header.decode().strip()]
        for rowno in range(2,rnd.randrange(14,23)):
            name=rnd.choice(names);lab=rnd.choice(labels); labs.add(lab)
            micros=rnd.randint(0,999_998); onset=f'0.{micros:06d}'; offset=f'0.{micros+1:06d}'
            lines.append('\t'.join([name,onset,offset,lab]))
            groups.setdefault(name,{'reference':[],'prediction':[]})[side].append((side[0]+str(rowno),lab,Decimal(onset),Decimal(offset)))
        inputs.append((rnd.choice(['','\ufeff'])+ending.join(lines)+rnd.choice(['',ending])).encode())
    d=check(*inputs)
    assert d['labels']==sorted(labs) and [r['id'] for r in d['recordings']]==sorted(groups)
    for r in d['recordings']:
        for side in ['reference','prediction']:
            assert [(x['id'],x['label'],Decimal(x['onset_s']),Decimal(x['offset_s'])) for x in r[side]]==sorted(groups[r['id']][side])
    rc,raw,err=run(exe,'evaluate',task,'--format','json')
    assert rc==0 and not err
print('40 generated round trips pass')
good=header+b'a\t0\t1\tz\n'
for invalid,c,p in [(b'', 'INVALID_TSV','prediction[1]'),(header+b'\r','INVALID_TSV','prediction[2]'),(header+b'x\t1\t2\tz\r','INVALID_TSV','prediction[2]'),(b'\xef\xbb\xbf'*2+header,'INVALID_TSV','prediction[1]'),(header+b'x\t1\t2\t\n','INVALID_SCHEMA','prediction[2].event_label'),(header+b'x\t1\t2\tz\n\n','INVALID_TSV','prediction[3]'),(header+b'\xc0\xaf','INVALID_UTF8','prediction'),(header+b'x\t1\t2592000.000001\tz','OUT_OF_RANGE','prediction[2].offset')]:
    check(good,invalid,{'code':c,'path':p})
check(header,header,{'code':'INVALID_SCHEMA','path':'labels'})
check(good,header)
for which,cap in [('recording',1000),('label',256)]:
    def row(i):
        return (f'f{i}\t0\t1\tz\n' if which=='recording' else f'f\t0\t1\tz{i}\n').encode()
    data=header+b''.join(row(i) for i in range(cap));check(data,header);check(data,header+row(cap),{'code':'RESOURCE_LIMIT','path':'prediction[2].'+('filename' if which=='recording' else 'event_label')},3)
x=header+(b'\t'*(8388608-2*len(header)))
t=time.perf_counter();check(x,header,{'code':'INVALID_TSV','path':'reference[2]'});print('8MiB combined with tabs secs',round(time.perf_counter()-t,3))
check(x,header+b'z',{'code':'RESOURCE_LIMIT','path':'tsv','observed':8388609},3)
a,b=root/'unpack/examples/tsv-reference.tsv',root/'unpack/examples/tsv-prediction.tsv'
check(a.read_bytes(),b.read_bytes())
for args in [('--version',),('evaluate',task),('evaluate',task,'--format','json'),('explain-pair',task,'--recording','clip.wav','--reference','r2','--prediction','p3'),('evaluate',),('evaluate','--format','json'),('evaluate',task,'--prediction','z'),('evaluate',task,'--format','bad'),('evaluate',task,'--format','json','--format','text'),('explain-pair',task,'--recording','--format','--reference','r2','--prediction','p3','--format','json')]:
    assert run(base,*args)==run(exe,*args),args
print('bounds/errors/archive/legacy OK')
with zipfile.ZipFile(next((root/'_build/publish').glob('*.zip'))) as z:
    assert len(z.namelist())==42 and all(z.read(n)==(root/n).read_bytes() for n in z.namelist())
